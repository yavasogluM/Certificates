﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev
{
    class Program
    {
        static void Main(string[] args)
        {
            //Soru1();
            //Soru2();
            //Soru3();
            //Soru4();
            Console.ReadKey();
        }

        static void Soru1()
        {
            Console.WriteLine("a değerini giriniz");
            int a = Convert.ToInt32(Console.ReadLine());
            int hesaplanacakA = (3 * a);

            Console.WriteLine("b değerini giriniz");
            int b = Convert.ToInt32(Console.ReadLine());
            int hesaplanacakB = (4 * (b * b));

            int sonuc = hesaplanacakA + hesaplanacakB;
            Console.WriteLine($"Sonuç: {sonuc}");
        }

        static void Soru2()
        {
            int pi = 3;
            Console.WriteLine("Yarıçap giriniz");
            int yarıçap = Convert.ToInt32(Console.ReadLine());

            int çevre = 2 * pi * yarıçap;
            Console.WriteLine($"Çevre: {çevre}");
            int alan = pi * (yarıçap * yarıçap);
            Console.Write($"Alan: {alan}");

        }

        static void Soru3()
        {
            Console.WriteLine("Vize Notunu Giriniz");
            int vize = Convert.ToInt32(Console.ReadLine());
            int hesaplanacakVize = (vize * 30) / 100;
            Console.WriteLine($"Vize Notundan:{hesaplanacakVize}");

            Console.WriteLine("Ödev Notunu Giriniz");
            int odev = Convert.ToInt32(Console.ReadLine());
            int hesaplanacakOdev = (odev * 30) / 100;
            Console.WriteLine($"Ödev Notundan:{hesaplanacakOdev}");

            Console.WriteLine("Final Notunu Giriniz");
            int final = Convert.ToInt32(Console.ReadLine());
            int hesaplanacakFinal = (final * 40) / 100;
            Console.WriteLine($"Final Notundan:{hesaplanacakFinal}");

            int sonuc = hesaplanacakVize + hesaplanacakOdev + hesaplanacakFinal;
            Console.WriteLine($"Başarı Notu: {sonuc}");
        }

        static void Soru4()
        {
            Console.WriteLine("Hız Değerini Giriniz");
            int hız = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Yol Değerini Giriniz");
            int yol = Convert.ToInt32(Console.ReadLine());

            int zaman = yol / hız;
            Console.WriteLine($"Tahmini Zaman Yaklaşık {zaman} Saat");
        }
    }
}
